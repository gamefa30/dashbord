#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth.2miners.com:2020
WALLET=nano_1duor6tiiraiz766xwpc3tpyk1fufw5rbwsqkc74h7tyrm8yyf91mxfz373t.op

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./opera --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./opera --algo ETHASH --pool $POOL --user $WALLET $@
done
